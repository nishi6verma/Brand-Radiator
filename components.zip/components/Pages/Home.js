import React from "react";

const Home = () => {
  return (
    <div>
      <div class="logo">
      <img src=
"https://brandradiator.com/images/BR-logo1.png" alt="logo" />
  </div>

  <section class="section">
    <div class="box-main">
        <div class="secondHalf">
            <h1 class="text-big" id="program">
                What is Machine Learning?
            </h1>
            <p class="text-small">
                Machine Learning is the field of study 
                that gives computers the capability to 
                learn without being explicitly 
                programmed. 
            </p>
        </div>
    </div>
</section>
    </div>
  );
};

export default Home;